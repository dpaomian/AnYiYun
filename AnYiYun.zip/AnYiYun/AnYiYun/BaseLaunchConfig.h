//
//  BaseLaunchConfig.h
//  AnYiYun
//
//  Created by wwr on 2017/7/19.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseLaunchConfig : NSObject

+ (void)launchingFlowConfig;

@end
