//
//  PublicWebViewController.h
//  AnYiYun
//
//  Created by wwr on 2017/7/21.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import "BaseViewController.h"

/**
 通用网页
 */
@interface PublicWebViewController : BaseViewController

@property(strong,nonatomic)NSString *myUrl;
@property(strong,nonatomic)NSString *titleStr;

@end
