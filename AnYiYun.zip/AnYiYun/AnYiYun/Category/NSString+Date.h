//
//  NSString+Date.h
//  BaseProject
//
//  Created by mac on 16/7/27.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Date)

+ (NSString *)dateExchangeWithTDateFormat:(NSString *)dateFormatStr;

@end
