


#import <UIKit/UIKit.h>

@interface UITextView (placeholder)
/** 注意先设置textView的字体 */
@property (nonatomic,copy) NSString *placeholder;
@end
