//
//  YYCalendarCollectionViewCell.m
//  AnYiYun
//
//  Created by 韩亚周 on 17/7/22.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import "YYCalendarCollectionViewCell.h"

@implementation YYCalendarCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

@end
