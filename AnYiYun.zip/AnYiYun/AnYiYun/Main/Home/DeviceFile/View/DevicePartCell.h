//
//  DevicePartCell.h
//  AnYiYun
//
//  Created by wuwanru on 29/7/17.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 主要部件cell
 */
@interface DevicePartCell : UITableViewCell

- (void)setCellContentWithLeftLabelStr:(NSString *)leftStr andRightLabelStr:(NSString *)rightStr;

@end
