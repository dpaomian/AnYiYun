//
//  AllApplicationReusableView.h
//  AnYiYun
//
//  Created by 韩亚周 on 17/7/26.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import <UIKit/UIKit.h>

/*!全部应用的区头*/
@interface AllApplicationReusableView : UICollectionReusableView

@property (strong, nonatomic) UILabel *titleLab;

@end
