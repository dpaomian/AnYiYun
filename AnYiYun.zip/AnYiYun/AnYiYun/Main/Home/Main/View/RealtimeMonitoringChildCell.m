//
//  RealtimeMonitoringChildCell.m
//  AnYiYun
//
//  Created by 韩亚周 on 17/7/27.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import "RealtimeMonitoringChildCell.h"

@implementation RealtimeMonitoringChildCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end
