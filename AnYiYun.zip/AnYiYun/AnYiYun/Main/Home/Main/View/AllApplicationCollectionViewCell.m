//
//  AllApplicationCollectionViewCell.m
//  AnYiYun
//
//  Created by 韩亚周 on 17/7/26.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import "AllApplicationCollectionViewCell.h"

@implementation AllApplicationCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

@end
