//
//  EquipmentAccountCell.h
//  AnYiYun
//
//  Created by 韩亚周 on 2017/7/28.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import <UIKit/UIKit.h>

/*!设备台账 单元格*/
@interface EquipmentAccountCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLab;

@end
