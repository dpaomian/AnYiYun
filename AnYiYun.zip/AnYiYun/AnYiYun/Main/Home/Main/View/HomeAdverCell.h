//
//  HomeAdverCell.h
//  AnYiYun
//
//  Created by wwr on 2017/7/25.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"

/**
 推广cell
 */
@interface HomeAdverCell : UITableViewCell

-(void)setCellContentWithModel:(HomeAdverModel *)itemModel;

@end
