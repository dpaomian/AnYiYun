//
//  FilterCollectionCell.m
//  AnYiYun
//
//  Created by 韩亚周 on 17/7/25.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import "FilterCollectionCell.h"

@implementation FilterCollectionCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

@end
