//
//  ElectricalFireTabBarRootViewController.h
//  AnYiYun
//
//  Created by 韩亚周 on 2017/7/29.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import <UIKit/UIKit.h>

/*!电气火灾*/
@interface ElectricalFireTabBarRootViewController : UITabBarController

@end
