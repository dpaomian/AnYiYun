//
//  YYSegmentedCollectionCell.m
//  AnYiYun
//
//  Created by 韩亚周 on 17/7/24.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import "YYSegmentedCollectionCell.h"

@implementation YYSegmentedCollectionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    _titleLable.textColor = UIColorFromRGB(0x000000);
}

@end
