//
//  PowerDistributionTabBarRootViewController.h
//  AnYiYun
//
//  Created by 韩亚周 on 2017/7/29.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import <UIKit/UIKit.h>

/*!供配电*/
@interface PowerDistributionTabBarRootViewController : UITabBarController

@end
