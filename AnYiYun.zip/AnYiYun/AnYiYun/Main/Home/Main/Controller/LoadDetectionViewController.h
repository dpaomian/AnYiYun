//
//  LoadDetectionViewController.h
//  AnYiYun
//
//  Created by 韩亚周 on 17/7/24.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import "BaseTableViewController.h"
#import "LoadDatectionHeaderView.h"
#import "LoadDatectionCell.h"

/*!负荷监测*/
@interface LoadDetectionViewController : BaseTableViewController

@end
