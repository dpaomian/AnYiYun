//
//  RealtimeMonitoringListModel.m
//  AnYiYun
//
//  Created by 韩亚周 on 2017/7/27.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import "RealtimeMonitoringListModel.h"

@implementation RealtimeMonitoringListModelList

@end

@implementation RealtimeMonitoringListModel

@end
