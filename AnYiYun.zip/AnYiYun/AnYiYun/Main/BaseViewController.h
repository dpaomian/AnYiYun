//
//  BaseViewController.h
//  AnYiYun
//
//  Created by wwr on 2017/7/19.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  所有VC基类
 *  用来设置统一VC样式
 */
@interface BaseViewController : UIViewController

-(void)setRightBarItem;

@end
