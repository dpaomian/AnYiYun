//
//  ModifyPasswordCell.h
//  AnYiYun
//
//  Created by wwr on 2017/7/24.
//  Copyright © 2017年 wwr. All rights reserved.
//

#import <UIKit/UIKit.h>

/**修改密码输入框*/
@interface ModifyPasswordCell : UITableViewCell

@property (nonatomic,strong)UIView *bottomLineView;

@property (nonatomic, strong) UILabel *leftTextLabel;

@property (nonatomic, strong) UITextField *pwdTextField;


@end
